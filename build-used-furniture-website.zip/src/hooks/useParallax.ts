import { useState, useEffect } from 'react';

export function useParallax() {
  const [scrollY, setScrollY] = useState(0);
  const [isReducedMotion, setIsReducedMotion] = useState(false);

  useEffect(() => {
    // Check if user prefers reduced motion
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setIsReducedMotion(mediaQuery.matches);

    const handleMotionChange = (e: MediaQueryListEvent) => {
      setIsReducedMotion(e.matches);
    };

    if (mediaQuery.addEventListener) {
      mediaQuery.addEventListener('change', handleMotionChange);
    }

    let ticking = false;

    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          setScrollY(window.pageYOffset || document.documentElement.scrollTop);
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      window.removeEventListener('scroll', handleScroll);
      if (mediaQuery.removeEventListener) {
        mediaQuery.removeEventListener('change', handleMotionChange);
      }
    };
  }, []);

  return {
    scrollY: isReducedMotion ? 0 : scrollY,
    isReducedMotion,
    // Layer 1: Background slow sink (depth: deep)
    layerDeep: isReducedMotion ? 0 : scrollY * 0.22,
    // Layer 2: Midground counter-float (depth: mid)
    layerMid: isReducedMotion ? 0 : -scrollY * 0.12,
    // Layer 3: Foreground gentle float (depth: near)
    layerForeground: isReducedMotion ? 0 : scrollY * 0.05,
  };
}
