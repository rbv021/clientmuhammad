import { WEEKLY_HOURS } from '../data/furnitureData';

export interface BusinessStatusResult {
  isOpen: boolean;
  statusText: string;
  subText: string;
  uaeTimeFormatted: string;
  currentDayName: string;
}

export function getUAEBusinessStatus(): BusinessStatusResult {
  // Compute current time in UAE (UTC+4)
  const now = new Date();
  // Format to Asia/Dubai
  const uaeDateStr = now.toLocaleString('en-US', { timeZone: 'Asia/Dubai' });
  const uaeDate = new Date(uaeDateStr);

  const dayOfWeek = uaeDate.getDay(); // 0 is Sunday, 5 is Friday, 6 is Saturday
  const currentHour = uaeDate.getHours();
  const currentMinute = uaeDate.getMinutes();
  const currentTimeDec = currentHour + currentMinute / 60;

  // Day names array matching Date.getDay()
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const currentDayName = days[dayOfWeek];

  const todaySchedule = WEEKLY_HOURS.find((h) => h.day === currentDayName) || WEEKLY_HOURS[0];

  const isOpen = currentTimeDec >= todaySchedule.rawStart && currentTimeDec < todaySchedule.rawEnd;

  const uaeTimeFormatted = uaeDate.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  });

  let statusText = '';
  let subText = '';

  if (isOpen) {
    statusText = 'OPEN NOW';
    subText = `Closes at 10:30 PM (UAE Time)`;
  } else {
    statusText = 'CLOSED NOW';
    if (currentTimeDec < todaySchedule.rawStart) {
      const openTimeFormatted = todaySchedule.rawStart === 16 ? '4:00 PM' : '9:00 AM';
      subText = `Opens today at ${openTimeFormatted}`;
    } else {
      const tomorrowIndex = (dayOfWeek + 1) % 7;
      const tomorrowDay = days[tomorrowIndex];
      const tomorrowSchedule = WEEKLY_HOURS.find((h) => h.day === tomorrowDay);
      const nextOpen = tomorrowSchedule?.rawStart === 16 ? '4:00 PM' : '9:00 AM';
      subText = `Opens tomorrow (${tomorrowDay}) at ${nextOpen}`;
    }
  }

  return {
    isOpen,
    statusText,
    subText,
    uaeTimeFormatted,
    currentDayName,
  };
}
