import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { ServicesSection } from './components/ServicesSection';
import { CategoriesShowcase } from './components/CategoriesShowcase';
import { WhatsAppEstimator } from './components/WhatsAppEstimator';
import { HowItWorks } from './components/HowItWorks';
import { ReviewsSection } from './components/ReviewsSection';
import { HoursAndLocation } from './components/HoursAndLocation';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';

export function App() {
  return (
    <div className="min-h-screen bg-[#12100E] text-[#EAE5DF] selection:bg-[#D4AF37] selection:text-black">
      {/* Navigation Header */}
      <Navbar />

      {/* Hero Section with Bespoke 4K Video Background & Scroll Parallax */}
      <Hero />

      {/* Main Content Sections */}
      <main>
        {/* About Showroom & Standards */}
        <AboutSection />

        {/* Services & Core Buying/Selling Categories */}
        <ServicesSection />

        {/* Interactive Instant WhatsApp Valuation Tool */}
        <WhatsAppEstimator />

        {/* Featured Inventory Showcase */}
        <CategoriesShowcase />

        {/* How It Works: Selling vs Buying */}
        <HowItWorks />

        {/* Verbatim Customer Reviews & Google Rating */}
        <ReviewsSection />

        {/* Showroom Hours & Deira Location Map */}
        <HoursAndLocation />

        {/* Contact Form & FAQs */}
        <ContactSection />
      </main>

      {/* Footer & Mobile Quick-Action Bar */}
      <Footer />
    </div>
  );
}

export default App;
