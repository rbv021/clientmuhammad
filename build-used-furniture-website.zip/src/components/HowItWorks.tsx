import React, { useState } from 'react';
import { Camera, Banknote, Truck, Store, CheckSquare, PackageCheck } from 'lucide-react';
import { BUSINESS_INFO } from '../data/furnitureData';

export const HowItWorks: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'selling' | 'buying'>('selling');

  const sellingSteps = [
    {
      step: '01',
      icon: Camera,
      title: 'Send Photos on WhatsApp',
      description: 'Snap 2–3 clear pictures of your furniture items and WhatsApp them to +971 55 949 9593 with your location.',
    },
    {
      step: '02',
      icon: Banknote,
      title: 'Fast Valuation & Deal Agreement',
      description: 'Our team reviews condition, brand, and size to provide an honest, competitive market price appraisal.',
    },
    {
      step: '03',
      icon: Truck,
      title: 'Free Pickup & Handover Payment',
      description: 'Our crew arrives with moving vans, carefully dismantles and loads the furniture, and provides payment on the spot.',
    },
  ];

  const buyingSteps = [
    {
      step: '01',
      icon: Store,
      title: 'Visit Showroom or Message Us',
      description: 'Visit our Deira showroom behind Al Sahar Hotel, or ask on WhatsApp for current photos matching your room dimensions.',
    },
    {
      step: '02',
      icon: CheckSquare,
      title: 'Inspect & Test Every Detail',
      description: 'Feel the materials, sit on the sofas, examine the wood joinery, and confirm measurements with complete peace of mind.',
    },
    {
      step: '03',
      icon: PackageCheck,
      title: 'Fast UAE Delivery & Assembly',
      description: 'We arrange safe transport directly to your home or office in Dubai, Sharjah, or neighboring Emirates with fixing included.',
    },
  ];

  const steps = activeTab === 'selling' ? sellingSteps : buyingSteps;

  return (
    <section className="py-20 bg-[#12100E] relative border-t border-[#261E17]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] text-xs font-semibold uppercase tracking-wider mb-3">
            <span>Simple 3-Step Process</span>
          </div>
          <h2 className="font-display text-2xl sm:text-4xl font-bold text-[#F7F4EE]">
            How Dealing With Us Works
          </h2>
          <p className="mt-2 text-sm sm:text-base text-[#A69B8E]">
            Transparent, straightforward, and zero complications whether you are moving out or moving in.
          </p>

          {/* Tab Switcher */}
          <div className="mt-6 inline-flex p-1 rounded-xl bg-[#1C1713] border border-[#31271D]">
            <button
              type="button"
              onClick={() => setActiveTab('selling')}
              className={`px-5 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                activeTab === 'selling'
                  ? 'bg-[#D4AF37] text-black shadow-md'
                  : 'text-[#A69B8E] hover:text-white'
              }`}
            >
              If You Are Selling Furniture
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('buying')}
              className={`px-5 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                activeTab === 'buying'
                  ? 'bg-[#D4AF37] text-black shadow-md'
                  : 'text-[#A69B8E] hover:text-white'
              }`}
            >
              If You Are Buying Furniture
            </button>
          </div>
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {steps.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={item.step}
                className="wood-card p-6 rounded-2xl border border-[#2F261E] relative flex flex-col justify-between"
              >
                {/* Step Number Top Banner */}
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 rounded-xl bg-[#221B15] border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37]">
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="font-display text-2xl font-black text-[#D4AF37]/35">
                    {item.step}
                  </span>
                </div>

                <div>
                  <h3 className="font-display text-lg font-bold text-white mb-2">
                    {item.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#A89D91] leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#261E17] text-[11px] text-[#D4AF37] font-medium flex items-center gap-1.5">
                  <span>Step {index + 1} of 3</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Action bar below steps */}
        <div className="mt-10 text-center">
          {activeTab === 'selling' ? (
            <a
              href={`https://wa.me/971559499593?text=${encodeURIComponent('Hello Muhammad Rafiq Used Furniture, I want to sell furniture. Can I send pictures?')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#25D366] text-black font-bold text-sm hover:brightness-110 shadow-lg shadow-[#25D366]/20 transition-all"
            >
              <span>Start Selling & Send Photos Now</span>
            </a>
          ) : (
            <a
              href={BUSINESS_INFO.googleMapsDirectionsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#D4AF37] text-black font-bold text-sm hover:brightness-110 shadow-lg shadow-[#D4AF37]/20 transition-all"
            >
              <span>Get Showroom Directions on Google Maps</span>
            </a>
          )}
        </div>
      </div>
    </section>
  );
};
