import React, { useState, useEffect } from 'react';
import { Clock, MapPin, Navigation, Phone, Train, Car, ExternalLink, Compass } from 'lucide-react';
import { BUSINESS_INFO, WEEKLY_HOURS } from '../data/furnitureData';
import { getUAEBusinessStatus, BusinessStatusResult } from '../utils/businessStatus';

export const HoursAndLocation: React.FC = () => {
  const [status, setStatus] = useState<BusinessStatusResult>(getUAEBusinessStatus());

  useEffect(() => {
    const timer = setInterval(() => {
      setStatus(getUAEBusinessStatus());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="location" className="py-24 bg-[#12100E] relative border-t border-[#261E17]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] text-xs font-semibold uppercase tracking-wider mb-3">
            <Compass className="w-3.5 h-3.5" />
            <span>Store Visit & Timings</span>
          </div>
          <h2 className="font-display text-2xl sm:text-4xl font-bold text-[#F7F4EE]">
            Showroom Hours & Deira Location
          </h2>
          <p className="mt-2 text-sm sm:text-base text-[#A69B8E]">
            Visit us in central Deira or call ahead. Free customer parking access and close proximity to Baniyas Square metro.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Operating Hours Card */}
          <div className="lg:col-span-5 space-y-6">
            <div className="wood-card p-6 sm:p-7 rounded-2xl border border-[#D4AF37]/30 shadow-xl relative overflow-hidden">
              {/* Header with live open badge */}
              <div className="flex items-center justify-between pb-4 border-b border-[#2C231B]">
                <div className="flex items-center gap-2.5">
                  <Clock className="w-5 h-5 text-[#D4AF37]" />
                  <h3 className="font-display text-lg font-bold text-white">Opening Hours</h3>
                </div>

                <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${
                  status.isOpen 
                    ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-500/40' 
                    : 'bg-amber-950/80 text-amber-400 border border-amber-500/40'
                }`}>
                  <span className={`w-2 h-2 rounded-full ${status.isOpen ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                  <span>{status.statusText}</span>
                </div>
              </div>

              {/* UAE Time display */}
              <div className="my-3 text-xs text-[#9E9387] flex items-center justify-between bg-[#1A1410] px-3 py-2 rounded-lg border border-[#2B2119]">
                <span>Current UAE Time:</span>
                <span className="font-semibold text-[#D4AF37]">{status.uaeTimeFormatted}</span>
              </div>

              {/* Weekly Schedule Table */}
              <div className="divide-y divide-[#261E17] text-xs sm:text-sm">
                {WEEKLY_HOURS.map((item) => {
                  const isToday = item.day === status.currentDayName;
                  return (
                    <div
                      key={item.day}
                      className={`py-2.5 flex items-center justify-between transition-colors ${
                        isToday ? 'font-bold text-[#D4AF37] bg-[#D4AF37]/5 px-2 rounded-md' : 'text-[#DDD4CA]'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        {item.day}
                        {isToday && (
                          <span className="text-[10px] font-semibold uppercase px-1.5 py-0.2 rounded bg-[#D4AF37] text-black">
                            Today
                          </span>
                        )}
                      </span>
                      <span className="font-medium text-right">{item.hours}</span>
                    </div>
                  );
                })}
              </div>

              {/* Friday Notice */}
              <div className="mt-4 pt-4 border-t border-[#2C231B] text-[11px] text-[#8C8074] leading-relaxed">
                * Note: On Fridays, we open at 4:00 PM after Friday prayers and remain open until 10:30 PM.
              </div>
            </div>

            {/* Quick Contact Box */}
            <div className="wood-card p-5 rounded-2xl border border-[#2F261E] space-y-3">
              <div className="text-xs font-semibold uppercase tracking-wider text-[#D4AF37]">
                Immediate Assistance & Pickup Hotline
              </div>
              <div className="flex items-center justify-between flex-wrap gap-2">
                <a
                  href={`tel:${BUSINESS_INFO.phoneRaw}`}
                  className="font-display text-xl font-bold text-white hover:text-[#D4AF37] transition-colors flex items-center gap-2"
                >
                  <Phone className="w-5 h-5 text-[#D4AF37]" />
                  <span>{BUSINESS_INFO.phone}</span>
                </a>
                <span className="text-xs text-emerald-400 font-semibold bg-emerald-950/60 px-2.5 py-1 rounded border border-emerald-800/40">
                  Tap to Call
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Address, Map, Directions & Transit */}
          <div className="lg:col-span-7 space-y-6">
            {/* Address Details Card */}
            <div className="wood-card p-6 sm:p-7 rounded-2xl border border-[#D4AF37]/30 shadow-xl space-y-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#D4AF37] uppercase tracking-wider">
                    <MapPin className="w-4 h-4 text-[#D4AF37]" />
                    <span>Physical Store Location</span>
                  </div>
                  <h3 className="font-display text-xl font-bold text-white mt-1">
                    Muhammad Rafiq Used Furniture Trading LLC
                  </h3>
                  <p className="text-sm text-[#DDD4CA] mt-1.5 leading-relaxed">
                    Behind Al Sahar Hotel, Al Musalla Road, Naif, Deira, Dubai, United Arab Emirates
                  </p>
                </div>

                {/* Direct Google Maps Direction CTA */}
                <a
                  href={BUSINESS_INFO.googleMapsDirectionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hidden sm:flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#D4AF37] hover:bg-[#E2C465] text-black font-bold text-xs shrink-0 transition-all shadow-md active:scale-95"
                >
                  <Navigation className="w-4 h-4" />
                  <span>Get Directions</span>
                </a>
              </div>

              {/* Transit & Proximity Pills */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="p-3 rounded-xl bg-[#1B1511] border border-[#2F241C] flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#251D17] flex items-center justify-center text-[#D4AF37] shrink-0">
                    <Train className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-white">Baniyas Square Metro</div>
                    <div className="text-[11px] text-[#8C8072]">340m walk (Green Line)</div>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[#1B1511] border border-[#2F241C] flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#251D17] flex items-center justify-center text-[#D4AF37] shrink-0">
                    <Car className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-white">Truck & Vehicle Access</div>
                    <div className="text-[11px] text-[#8C8072]">Easy loading zone for vans</div>
                  </div>
                </div>
              </div>

              {/* Map embed iframe centered on coordinates (25.2719594, 55.3083155) */}
              <div className="relative w-full h-[280px] sm:h-[320px] rounded-xl overflow-hidden border border-[#33281E] bg-[#1A1410] shadow-inner">
                <iframe
                  title="Google Maps Location of Muhammad Rafiq Used Furniture"
                  src={`https://maps.google.com/maps?q=${BUSINESS_INFO.coordinates.lat},${BUSINESS_INFO.coordinates.lng}&z=16&output=embed`}
                  className="w-full h-full border-0 filter contrast-[1.05] brightness-[0.95]"
                  loading="lazy"
                  allowFullScreen
                />
              </div>

              {/* Navigation Action Buttons Bar */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <a
                  href={BUSINESS_INFO.googleMapsDirectionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#D4AF37] hover:bg-[#E2C465] text-black font-bold text-xs sm:text-sm transition-all"
                >
                  <Navigation className="w-4 h-4" />
                  <span>Open in Google Maps Directions</span>
                </a>

                <a
                  href={BUSINESS_INFO.wazeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-1.5 py-3 px-4 rounded-xl bg-[#1F1914] hover:bg-[#2C231C] text-[#DDD] hover:text-white border border-[#3A3026] text-xs sm:text-sm font-semibold transition-colors"
                >
                  <span>Waze</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
