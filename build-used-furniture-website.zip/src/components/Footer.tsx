import React from 'react';
import { Phone, MapPin, Clock, MessageCircle, ArrowUp, Navigation } from 'lucide-react';
import { BUSINESS_INFO } from '../data/furnitureData';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <footer className="bg-[#0B0908] text-[#B0A69C] border-t border-[#241C16] relative pt-16 pb-24 lg:pb-16 select-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-[#211913]">
            {/* Column 1: Brand & Bio */}
            <div className="lg:col-span-4 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#1C1611] border border-[#D4AF37]/40 flex items-center justify-center p-1.5 shadow-md">
                  <svg viewBox="0 0 40 40" className="w-full h-full text-[#D4AF37]" fill="none" stroke="currentColor">
                    <path d="M8 26h24v-2c0-2.2-1.8-4-4-4H12c-2.2 0-4 1.8-4 4v2z" fill="#D4AF37" fillOpacity="0.25" strokeWidth="2" />
                    <path d="M12 20V12c0-2.2 1.8-4 4-4h8c2.2 0 4 1.8 4 4v8" strokeWidth="2" strokeLinecap="round" />
                    <path d="M6 21c0-1.5 1-2.5 2.5-2.5h1.5v5H8.5C7 23.5 6 22.5 6 21z" strokeWidth="1.5" />
                    <path d="M34 21c0-1.5-1-2.5-2.5-2.5H30v5h1.5c1.5 0 2.5-1 2.5-2.5z" strokeWidth="1.5" />
                    <path d="M11 26v4M29 26v4" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </div>
                <div>
                  <div className="font-display font-bold text-base text-white tracking-wider">
                    MUHAMMAD RAFIQ
                  </div>
                  <div className="text-[10px] tracking-widest text-[#D4AF37] font-semibold">
                    USED FURNITURE TRADING LLC
                  </div>
                </div>
              </div>

              <p className="text-xs text-[#998D80] leading-relaxed">
                Dubai’s reliable pre-owned furniture buyers and sellers located in Deira. We buy and sell living room sets, solid wood dining tables, bedroom suites, and commercial office furniture with honest evaluations and rapid doorstep pickup.
              </p>

              <div className="pt-2 flex items-center gap-3">
                <a
                  href={`tel:${BUSINESS_INFO.phoneRaw}`}
                  className="px-3 py-1.5 rounded-lg bg-[#1C1611] border border-[#3A2F24] hover:border-[#D4AF37] text-xs text-[#D4AF37] font-semibold transition-colors flex items-center gap-1.5"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Call Direct</span>
                </a>
                <a
                  href={BUSINESS_INFO.googleMapsDirectionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-lg bg-[#1C1611] border border-[#3A2F24] hover:border-[#D4AF37] text-xs text-[#EAE4DF] hover:text-[#D4AF37] font-semibold transition-colors flex items-center gap-1.5"
                >
                  <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Map Directions</span>
                </a>
              </div>
            </div>

            {/* Column 2: Quick Links */}
            <div className="lg:col-span-2 space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Navigation</h4>
              <ul className="space-y-2 text-xs">
                <li><a href="#about" className="hover:text-[#D4AF37] transition-colors">About Showroom</a></li>
                <li><a href="#services" className="hover:text-[#D4AF37] transition-colors">What We Buy & Sell</a></li>
                <li><a href="#inventory" className="hover:text-[#D4AF37] transition-colors">Featured Inventory</a></li>
                <li><a href="#quote" className="hover:text-[#D4AF37] transition-colors">WhatsApp Valuation</a></li>
                <li><a href="#reviews" className="hover:text-[#D4AF37] transition-colors">Customer Reviews</a></li>
                <li><a href="#location" className="hover:text-[#D4AF37] transition-colors">Hours & Directions</a></li>
              </ul>
            </div>

            {/* Column 3: Contact & Address */}
            <div className="lg:col-span-3 space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Showroom Contact</h4>
              <ul className="space-y-2.5 text-xs">
                <li className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                  <a
                    href={BUSINESS_INFO.googleMapsDirectionsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-[#D4AF37] transition-colors leading-relaxed"
                  >
                    Behind Al Sahar Hotel, Al Musalla Rd, Naif, Deira, Dubai, UAE
                  </a>
                </li>
                <li className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <a href={`tel:${BUSINESS_INFO.phoneRaw}`} className="hover:text-[#D4AF37] font-semibold text-white transition-colors">
                    {BUSINESS_INFO.phone}
                  </a>
                </li>
                <li className="flex items-center gap-2">
                  <MessageCircle className="w-4 h-4 text-[#25D366] shrink-0" />
                  <a
                    href={BUSINESS_INFO.whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-emerald-400 text-[#DDD] transition-colors"
                  >
                    WhatsApp: +971 55 949 9593
                  </a>
                </li>
              </ul>
            </div>

            {/* Column 4: Hours Snapshot */}
            <div className="lg:col-span-3 space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Working Timings</span>
              </h4>
              <div className="text-xs space-y-1.5 text-[#9E9387]">
                <div className="flex justify-between">
                  <span>Saturday – Thursday:</span>
                  <span className="text-white font-medium">9:00 AM – 10:30 PM</span>
                </div>
                <div className="flex justify-between">
                  <span>Friday:</span>
                  <span className="text-white font-medium">4:00 PM – 10:30 PM</span>
                </div>
                <div className="pt-2 text-[11px] text-[#D4AF37]">
                  Same-Day Pickup Available Across Dubai & Sharjah
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Bar: Copyright & Back to Top */}
          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#7A6F63]">
            <div>
              &copy; {new Date().getFullYear()} Muhammad Rafiq Used Furniture Trading LLC. All rights reserved. Deira, Dubai, UAE.
            </div>

            <div className="flex items-center gap-4">
              <span className="hidden sm:inline">Licensed Pre-Owned Furniture Dealer in Dubai</span>
              <button
                type="button"
                onClick={scrollToTop}
                className="flex items-center gap-1.5 text-[#A89D91] hover:text-[#D4AF37] transition-colors p-1"
                aria-label="Back to top"
              >
                <span>Back to Top</span>
                <ArrowUp className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </footer>

      {/* ========================================================
          STICKY MOBILE ACTION BAR (Fixed Bottom)
          Ensures high conversion for mobile visitors
          ======================================================== */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#120E0C]/95 backdrop-blur-md border-t border-[#31271D] p-2.5 px-3 shadow-2xl flex items-center gap-2">
        {/* Call CTA */}
        <a
          href={`tel:${BUSINESS_INFO.phoneRaw}`}
          className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B89020] text-black font-bold text-xs shadow-md active:scale-95"
        >
          <Phone className="w-4 h-4 fill-black" />
          <span>Call Now</span>
        </a>

        {/* WhatsApp Photos CTA */}
        <a
          href={`https://wa.me/971559499593?text=${encodeURIComponent('Hello Muhammad Rafiq Used Furniture, I would like to inquire about furniture:')}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-[#25D366] text-black font-bold text-xs shadow-md active:scale-95"
        >
          <MessageCircle className="w-4 h-4" />
          <span>WhatsApp</span>
        </a>

        {/* Directions Icon Button */}
        <a
          href={BUSINESS_INFO.googleMapsDirectionsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="p-2.5 rounded-xl bg-[#221B15] text-[#D4AF37] border border-[#3A2E22] active:scale-95 shrink-0"
          title="Google Maps Directions"
          aria-label="Google Maps Directions"
        >
          <Navigation className="w-4 h-4" />
        </a>
      </div>
    </>
  );
};
