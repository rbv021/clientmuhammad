import React from 'react';
import { CheckCircle2, MapPin, Phone, ArrowUpRight } from 'lucide-react';
import { BUSINESS_INFO } from '../data/furnitureData';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-[#14100E] relative overflow-hidden">
      {/* Background Accent Lines */}
      <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-[#1B1612] to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Custom Showroom Inspection Image & Trust Stats */}
          <div className="lg:col-span-6 space-y-6">
            <div className="relative rounded-2xl overflow-hidden border border-[#D4AF37]/30 shadow-2xl group">
              <img
                src="/images/showroom-inspection.jpg"
                alt="Showroom inspection of authentic solid wood furniture at Muhammad Rafiq Used Furniture Deira Dubai"
                className="w-full h-[400px] sm:h-[460px] object-cover object-center group-hover:scale-105 transition-transform duration-700"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent" />

              {/* Bottom Overlay Info Card */}
              <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl wood-card border border-[#D4AF37]/30 backdrop-blur-md">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-wider text-[#D4AF37]">
                      Showroom & Warehouse Inspection
                    </div>
                    <div className="text-sm font-bold text-white mt-0.5">
                      Behind Al Sahar Hotel, Al Musalla Rd
                    </div>
                  </div>
                  <a
                    href={BUSINESS_INFO.googleMapsDirectionsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2.5 rounded-lg bg-[#D4AF37] text-black hover:brightness-110 transition-all shrink-0"
                    title="Get Directions on Google Maps"
                  >
                    <ArrowUpRight className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </div>

            {/* Quick 3 Pillar Cards */}
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="wood-card p-3.5 rounded-xl border border-[#2E251E]">
                <div className="text-[#D4AF37] font-display font-bold text-lg sm:text-xl">4.7 ★</div>
                <div className="text-[11px] text-[#A69B8F] mt-1">Google Rating</div>
              </div>
              <div className="wood-card p-3.5 rounded-xl border border-[#2E251E]">
                <div className="text-[#D4AF37] font-display font-bold text-lg sm:text-xl">Same-Day</div>
                <div className="text-[11px] text-[#A69B8F] mt-1">Pickup Available</div>
              </div>
              <div className="wood-card p-3.5 rounded-xl border border-[#2E251E]">
                <div className="text-[#D4AF37] font-display font-bold text-lg sm:text-xl">100%</div>
                <div className="text-[11px] text-[#A69B8F] mt-1">Inspected Items</div>
              </div>
            </div>
          </div>

          {/* Right Column: Narrative & Standards */}
          <div className="lg:col-span-6 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] text-xs font-semibold uppercase tracking-wider">
              <span>About Our Showroom</span>
            </div>

            <h2 className="font-display text-2xl sm:text-4xl font-bold text-[#F7F4EE] leading-tight">
              A Direct, Reliable Marketplace for Furniture in Dubai
            </h2>

            <p className="text-sm sm:text-base text-[#D1C6BC] leading-relaxed">
              Conveniently located behind Al Sahar Hotel on Al Musalla Road in Deira, <strong className="text-white font-medium">Muhammad Rafiq Used Furniture Trading LLC</strong> connects homeowners, tenants, and businesses looking to buy or sell quality pre-owned furniture.
            </p>

            <p className="text-sm sm:text-base text-[#B5ABA0] leading-relaxed">
              Whether you are furnishing a new apartment on a sensible budget or liquidating an entire villa or corporate office prior to relocation, we eliminate the stress of classifieds with direct WhatsApp valuations, transparent evaluations, and our own logistics vehicles.
            </p>

            {/* Feature Checklist */}
            <div className="space-y-3.5 pt-2">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37] shrink-0 mt-0.5">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">Every Item Physically Vetted</h4>
                  <p className="text-xs text-[#9E9388]">We check wood joints, springs, foam density, upholstery condition, and electronics to ensure pieces are ready for immediate use.</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37] shrink-0 mt-0.5">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">Prompt Pickup with Own Team</h4>
                  <p className="text-xs text-[#9E9388]">No need to hire private movers. Our crews handle the dismantling, lifting, and transport directly from your doorstep across Dubai and Sharjah.</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37] shrink-0 mt-0.5">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">Central Deira Location</h4>
                  <p className="text-xs text-[#9E9388]">Steps away from Baniyas Square Metro Station and Naif Park on Al Musalla Road. Walk in anytime during operating hours to browse inventory.</p>
                </div>
              </div>
            </div>

            {/* Direct Connect CTA */}
            <div className="pt-4 flex flex-wrap items-center gap-4">
              <a
                href={`tel:${BUSINESS_INFO.phoneRaw}`}
                className="flex items-center gap-2 px-5 py-3 rounded-xl bg-[#D4AF37] hover:bg-[#E2C465] text-black font-bold text-xs sm:text-sm transition-all"
              >
                <Phone className="w-4 h-4 fill-black" />
                <span>Call Us: {BUSINESS_INFO.phone}</span>
              </a>

              <a
                href={BUSINESS_INFO.googleMapsDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-3 rounded-xl bg-[#201A15] hover:bg-[#2C231C] text-[#E8E4DF] border border-[#3A3026] hover:border-[#D4AF37]/50 text-xs sm:text-sm font-semibold transition-all"
              >
                <MapPin className="w-4 h-4 text-[#D4AF37]" />
                <span>Visit Showroom</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
