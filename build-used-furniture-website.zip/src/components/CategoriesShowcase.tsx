import React, { useState } from 'react';
import { FURNITURE_ITEMS, BUSINESS_INFO } from '../data/furnitureData';
import { FurnitureItem } from '../types';
import { MessageCircle, Phone, Sparkles, Check, Eye } from 'lucide-react';

export const CategoriesShowcase: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedItem, setSelectedItem] = useState<FurnitureItem | null>(null);

  const categories = [
    { key: 'all', label: 'All Inventory' },
    { key: 'living', label: 'Living Room' },
    { key: 'bedroom', label: 'Bedroom Suites' },
    { key: 'dining', label: 'Dining Sets' },
    { key: 'office', label: 'Office & Commercial' },
  ];

  const filteredItems =
    activeCategory === 'all'
      ? FURNITURE_ITEMS
      : FURNITURE_ITEMS.filter((item) => item.category === activeCategory);

  return (
    <section id="inventory" className="py-24 bg-[#14100E] relative border-t border-[#261E17]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] text-xs font-semibold uppercase tracking-wider mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Showroom Showcase</span>
            </div>
            <h2 className="font-display text-2xl sm:text-4xl font-bold text-[#F7F4EE]">
              Featured Pre-Owned Selections
            </h2>
            <p className="mt-2 text-sm sm:text-base text-[#A89D91] max-w-xl">
              Representative examples from our revolving showroom in Deira. Our inventory updates daily as new residential and commercial estates are acquired.
            </p>
          </div>

          {/* Filter Tabs */}
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat.key}
                type="button"
                onClick={() => setActiveCategory(cat.key)}
                className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                  activeCategory === cat.key
                    ? 'bg-[#D4AF37] text-black shadow-md'
                    : 'bg-[#1F1914] text-[#A69B8E] hover:text-white border border-[#30261C]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Inventory Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="wood-card wood-card-hover rounded-xl overflow-hidden border border-[#2E251D] flex flex-col justify-between group"
            >
              {/* Image & Condition Tag */}
              <div className="relative aspect-[4/3] overflow-hidden bg-[#1D1713]">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />

                {/* Condition Badge */}
                <span className="absolute top-3 left-3 text-[10px] font-bold px-2.5 py-1 rounded-md bg-[#16120F]/90 text-[#E8C258] border border-[#D4AF37]/40 backdrop-blur-sm shadow-md">
                  {item.condition}
                </span>

                {/* Quick inspect button */}
                <button
                  type="button"
                  onClick={() => setSelectedItem(item)}
                  className="absolute bottom-3 right-3 p-2 rounded-lg bg-black/70 hover:bg-[#D4AF37] text-white hover:text-black border border-white/20 transition-all opacity-0 group-hover:opacity-100 focus:opacity-100"
                  title="View Item Details"
                  aria-label={`View details for ${item.title}`}
                >
                  <Eye className="w-4 h-4" />
                </button>
              </div>

              {/* Item Info */}
              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <div className="text-[11px] font-medium text-[#D4AF37] uppercase tracking-wider mb-1">
                    {item.categoryLabel}
                  </div>
                  <h3 className="font-display text-sm font-bold text-white group-hover:text-[#D4AF37] transition-colors line-clamp-1">
                    {item.title}
                  </h3>
                  <p className="mt-1.5 text-xs text-[#9E9387] line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>
                  <div className="mt-3 text-[11px] text-[#C2B7AC] flex items-center gap-1">
                    <span className="text-[#8A7E72]">Material:</span>
                    <span className="font-medium text-[#E0D8CE]">{item.material}</span>
                  </div>
                </div>

                {/* Action Row */}
                <div className="mt-4 pt-3 border-t border-[#261E17] flex items-center gap-2">
                  <a
                    href={`https://wa.me/971559499593?text=${encodeURIComponent(`Hello Muhammad Rafiq Used Furniture, I am inquiring about the "${item.title}" (${item.categoryLabel}). Is this or similar items currently available?`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-[#25D366]/15 hover:bg-[#25D366]/25 border border-[#25D366]/35 text-[#4BED86] text-xs font-semibold transition-colors"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </a>

                  <button
                    type="button"
                    onClick={() => setSelectedItem(item)}
                    className="py-2 px-3 rounded-lg bg-[#251E18] hover:bg-[#342A21] text-xs text-[#DDD] font-medium border border-[#3A3026] transition-colors"
                  >
                    Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Notice on rotating stock */}
        <div className="mt-12 wood-card p-6 rounded-2xl border border-[#D4AF37]/30 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-center sm:text-left">
            <h4 className="font-display font-bold text-white text-base">Looking for a specific furniture style or size?</h4>
            <p className="text-xs text-[#A89D91] mt-1">Our stock changes daily with new arrivals from Dubai villas & offices. Message us what you need and we will send matching photos.</p>
          </div>
          <a
            href={`https://wa.me/971559499593?text=${encodeURIComponent('Hello Muhammad Rafiq Used Furniture, I am looking for a specific furniture item:')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 rounded-xl bg-[#D4AF37] hover:bg-[#E2C465] text-black font-bold text-xs sm:text-sm shrink-0 transition-all"
          >
            Ask for Today’s Stock
          </a>
        </div>
      </div>

      {/* Item Details Modal */}
      {selectedItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn"
          onClick={() => setSelectedItem(null)}
        >
          <div
            className="wood-card max-w-lg w-full rounded-2xl border border-[#D4AF37]/40 p-6 shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative aspect-video rounded-xl overflow-hidden mb-4">
              <img
                src={selectedItem.image}
                alt={selectedItem.title}
                className="w-full h-full object-cover"
              />
              <span className="absolute top-3 left-3 text-xs font-bold px-2.5 py-1 rounded bg-black/80 text-[#D4AF37] border border-[#D4AF37]/40">
                {selectedItem.condition}
              </span>
            </div>

            <div className="text-xs font-semibold text-[#D4AF37] uppercase tracking-wider">
              {selectedItem.categoryLabel}
            </div>
            <h3 className="font-display text-xl font-bold text-white mt-1">
              {selectedItem.title}
            </h3>
            <p className="mt-2 text-xs sm:text-sm text-[#B8ACA0] leading-relaxed">
              {selectedItem.description}
            </p>

            <div className="mt-4 p-3 rounded-lg bg-[#181310] border border-[#2B221A] space-y-1.5 text-xs">
              <div className="flex justify-between text-[#A89D91]">
                <span>Material:</span>
                <span className="text-white font-medium">{selectedItem.material}</span>
              </div>
              <div className="flex justify-between text-[#A89D91]">
                <span>Inspection:</span>
                <span className="text-emerald-400 font-medium">Passed Multi-Point Check</span>
              </div>
            </div>

            <div className="mt-4">
              <span className="text-xs font-semibold text-[#D4AF37] uppercase">Key Features:</span>
              <ul className="mt-1.5 space-y-1">
                {selectedItem.features.map((f, i) => (
                  <li key={i} className="text-xs text-[#CCC] flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-6 flex items-center gap-3">
              <a
                href={`https://wa.me/971559499593?text=${encodeURIComponent(`Hello, I want to inquire about purchasing or viewing: "${selectedItem.title}" at your Deira showroom.`)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#25D366] text-black font-bold text-xs sm:text-sm hover:brightness-110 transition-all"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp About This Item</span>
              </a>
              <a
                href={`tel:${BUSINESS_INFO.phoneRaw}`}
                className="p-2.5 rounded-xl bg-[#2B231B] text-[#D4AF37] border border-[#3E3327] hover:border-[#D4AF37] transition-all"
                title="Call Shop"
              >
                <Phone className="w-5 h-5" />
              </a>
              <button
                type="button"
                onClick={() => setSelectedItem(null)}
                className="py-2.5 px-4 rounded-xl bg-[#1C1612] hover:bg-[#2A211B] text-xs text-[#A89D91] hover:text-white border border-[#30261C] transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
