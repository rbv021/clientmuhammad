import React, { useRef, useState, useEffect } from 'react';
import { Phone, MessageCircle, Star, Truck, CheckCircle, Play, Pause, MapPin, ChevronDown, Sparkles } from 'lucide-react';
import { BUSINESS_INFO } from '../data/furnitureData';
import { useParallax } from '../hooks/useParallax';

// High-definition 4K cinematic furniture & interior videos (at least 1080p / 2160p UHD)
const HERO_VIDEOS = [
  {
    title: 'Showroom Living Interior',
    src: 'https://videos.pexels.com/video-files/6356433/6356433-uhd_3840_2160_24fps.mp4',
    poster: '/images/hero-poster.jpg',
  },
  {
    title: 'Modern Architecture & Lounge',
    src: 'https://videos.pexels.com/video-files/18531410/18531410-uhd_3840_2160_60fps.mp4',
    poster: '/images/og-image.jpg',
  },
];

export const Hero: React.FC = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [activeVideoIndex, setActiveVideoIndex] = useState(0);
  const [videoLoaded, setVideoLoaded] = useState(false);
  const { layerDeep, layerMid, layerForeground, isReducedMotion } = useParallax();

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch((e) => console.log('Autoplay restriction:', e));
    }
  };

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.play().catch(() => {
        setIsPlaying(false);
      });
    }
  }, [activeVideoIndex]);

  return (
    <section className="relative min-h-[92vh] flex items-center justify-center overflow-hidden bg-[#12100E]">
      {/* ========================================================
          PARALLAX LAYER 1: Deep Video Background (Depth: -1)
          ======================================================== */}
      <div
        className="absolute inset-0 w-full h-full will-change-transform pointer-events-none parallax-layer"
        style={{
          transform: isReducedMotion ? 'none' : `translate3d(0, ${layerDeep * 0.4}px, 0) scale(1.08)`,
          transition: isReducedMotion ? 'none' : 'transform 0.05s ease-out',
        }}
      >
        <video
          ref={videoRef}
          key={HERO_VIDEOS[activeVideoIndex].src}
          src={HERO_VIDEOS[activeVideoIndex].src}
          poster={HERO_VIDEOS[activeVideoIndex].poster}
          autoPlay
          muted
          loop
          playsInline
          onCanPlayThrough={() => setVideoLoaded(true)}
          className="w-full h-full object-cover object-center filter brightness-[0.42] contrast-[1.08]"
        />

        {/* Ambient Overlay Gradients */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#12100E] via-[#12100E]/45 to-[#12100E]/70" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_transparent_20%,_rgba(18,16,14,0.7)_85%)]" />
      </div>

      {/* ========================================================
          PARALLAX LAYER 2: Floating Ambient Accents (Depth: Mid)
          ======================================================== */}
      <div
        className="absolute inset-0 w-full h-full pointer-events-none hidden md:block max-w-7xl mx-auto px-4 parallax-layer"
        style={{
          transform: isReducedMotion ? 'none' : `translate3d(0, ${layerMid * 0.8}px, 0)`,
          transition: isReducedMotion ? 'none' : 'transform 0.05s ease-out',
        }}
      >
        {/* Floating Verified Google Rating Badge (Top Right) */}
        <div className="absolute top-24 right-8 lg:right-12 wood-card p-4 rounded-xl border border-[#D4AF37]/35 shadow-2xl flex items-center gap-3 backdrop-blur-md animate-pulse">
          <div className="w-10 h-10 rounded-full bg-[#D4AF37]/15 flex items-center justify-center text-[#D4AF37] border border-[#D4AF37]/30">
            <Star className="w-5 h-5 fill-[#D4AF37]" />
          </div>
          <div>
            <div className="flex items-center gap-1 text-sm font-bold text-white">
              <span>{BUSINESS_INFO.rating}</span>
              <div className="flex text-[#D4AF37]">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-[#D4AF37]" />
                ))}
              </div>
            </div>
            <div className="text-[11px] text-[#C2B8AD]">
              {BUSINESS_INFO.reviewsCount}+ Verified UAE Reviews
            </div>
          </div>
        </div>

        {/* Floating Same-Day Transport Badge (Bottom Left) */}
        <div className="absolute bottom-24 left-8 lg:left-12 wood-card p-3.5 rounded-xl border border-[#D4AF37]/30 shadow-2xl flex items-center gap-3 backdrop-blur-md">
          <div className="w-9 h-9 rounded-lg bg-[#241D17] border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37]">
            <Truck className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-semibold text-white flex items-center gap-1.5">
              <span>Same-Day Doorstep Pickup</span>
              <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="text-[10px] text-[#A69C90]">Dubai, Sharjah & All UAE Emirates</div>
          </div>
        </div>
      </div>

      {/* ========================================================
          PARALLAX LAYER 3: Main Foreground Hero Content (Depth: Near)
          ======================================================== */}
      <div
        className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center flex flex-col items-center parallax-layer"
        style={{
          transform: isReducedMotion ? 'none' : `translate3d(0, ${layerForeground * 0.5}px, 0)`,
          transition: isReducedMotion ? 'none' : 'transform 0.05s ease-out',
        }}
      >
        {/* Category Pill Tag */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#1F1914]/90 border border-[#D4AF37]/40 text-[#D4AF37] text-xs font-medium tracking-wide uppercase mb-6 shadow-lg backdrop-blur-sm">
          <Sparkles className="w-3.5 h-3.5 text-[#E5C158]" />
          <span>Premier Pre-Owned Furniture Buyers & Sellers in Dubai</span>
        </div>

        {/* Main Headline */}
        <h1 className="font-display text-3xl sm:text-5xl lg:text-6xl font-extrabold text-[#FBF9F5] tracking-tight leading-[1.15] max-w-4xl">
          Dubai’s Trusted Showroom for{' '}
          <span className="gold-gradient-text block sm:inline">Quality Pre-Owned</span>{' '}
          Home & Office Furniture
        </h1>

        {/* Subtitle strictly grounded in real category and reviews */}
        <p className="mt-6 text-base sm:text-lg text-[#D1C7BC] max-w-2xl leading-relaxed font-light">
          We buy and sell clean living room sofa sets, solid wood dining tables, bedroom suites, and corporate office furniture. Prompt valuations, fair pricing, and rapid doorstep pickup in Deira and across the UAE.
        </p>

        {/* Primary Call to Actions */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3.5 w-full max-w-md">
          {/* Sell / WhatsApp Photo CTA */}
          <a
            href={`https://wa.me/971559499593?text=${encodeURIComponent('Hello Muhammad Rafiq Used Furniture, I want to sell furniture. Here are the details and photos:')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto flex-1 flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-[#25D366] hover:bg-[#20ba5a] text-black font-bold text-sm tracking-wide shadow-xl shadow-[#25D366]/20 transition-all transform active:scale-95 group"
          >
            <MessageCircle className="w-5 h-5 text-black" />
            <span>Send Photos on WhatsApp</span>
          </a>

          {/* Tap-to-Call direct CTA */}
          <a
            href={`tel:${BUSINESS_INFO.phoneRaw}`}
            className="w-full sm:w-auto flex-1 flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-[#D4AF37] via-[#E2C465] to-[#B89020] hover:brightness-110 text-black font-bold text-sm tracking-wide shadow-xl shadow-[#D4AF37]/20 transition-all transform active:scale-95 group"
          >
            <Phone className="w-4 h-4 fill-black" />
            <span>Call: {BUSINESS_INFO.phone}</span>
          </a>
        </div>

        {/* Secondary Navigation & Directions link */}
        <div className="mt-5 flex flex-wrap items-center justify-center gap-4 text-xs sm:text-sm text-[#BDB2A5]">
          <a
            href={BUSINESS_INFO.googleMapsDirectionsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 hover:text-[#D4AF37] transition-colors underline decoration-[#D4AF37]/50 underline-offset-4"
          >
            <MapPin className="w-4 h-4 text-[#D4AF37]" />
            <span>Behind Al Sahar Hotel, Al Musalla Rd, Deira</span>
          </a>
          <span className="text-[#554A3E]">•</span>
          <a
            href="#inventory"
            className="hover:text-[#D4AF37] transition-colors"
          >
            Browse Available Categories &darr;
          </a>
        </div>

        {/* 3 Quick Value Badges */}
        <div className="mt-12 grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4 w-full max-w-3xl text-left">
          <div className="wood-card p-3.5 sm:p-4 rounded-xl border border-[#3A3026]">
            <div className="text-[#D4AF37] font-semibold text-xs sm:text-sm">Fair Valuations</div>
            <div className="text-[11px] sm:text-xs text-[#A89D91] mt-0.5">Quick photo appraisal with honest market rates</div>
          </div>
          <div className="wood-card p-3.5 sm:p-4 rounded-xl border border-[#3A3026]">
            <div className="text-[#D4AF37] font-semibold text-xs sm:text-sm">Free Doorstep Pickup</div>
            <div className="text-[11px] sm:text-xs text-[#A89D91] mt-0.5">Own moving team handles heavy furniture lifting</div>
          </div>
          <div className="wood-card p-3.5 sm:p-4 rounded-xl border border-[#3A3026] col-span-2 sm:col-span-1">
            <div className="text-[#D4AF37] font-semibold text-xs sm:text-sm">Inspected Quality</div>
            <div className="text-[11px] sm:text-xs text-[#A89D91] mt-0.5">Checked for structural stability & clean finishes</div>
          </div>
        </div>
      </div>

      {/* Video Controls & Scene Switcher (Bottom Right) */}
      <div className="absolute bottom-5 right-5 z-20 flex items-center gap-2 wood-card p-1.5 rounded-lg border border-[#D4AF37]/25 text-xs text-[#DDD] shadow-lg">
        <button
          type="button"
          onClick={togglePlay}
          className="p-1.5 rounded hover:bg-[#2A231C] text-[#D4AF37] transition-colors focus:outline-none"
          title={isPlaying ? 'Pause cinematic background video' : 'Play cinematic background video'}
          aria-label={isPlaying ? 'Pause video' : 'Play video'}
        >
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
        </button>

        <span className="text-[10px] text-[#9A8F82] px-1 hidden sm:inline">
          {videoLoaded ? '4K Cinema' : 'Loading...'}
        </span>

        {/* Scene switcher button */}
        <button
          type="button"
          onClick={() => setActiveVideoIndex((prev) => (prev === 0 ? 1 : 0))}
          className="px-2 py-1 rounded bg-[#272019] hover:bg-[#342B22] text-[10px] text-[#E0D8CE] border border-[#3D3328] transition-colors"
          title="Switch cinematic camera angle"
        >
          Switch Scene
        </button>
      </div>

      {/* Down Scroll Anchor */}
      <a
        href="#about"
        className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 p-2 text-[#9A8F82] hover:text-[#D4AF37] transition-colors animate-bounce"
        aria-label="Scroll down to About section"
      >
        <ChevronDown className="w-5 h-5" />
      </a>
    </section>
  );
};
