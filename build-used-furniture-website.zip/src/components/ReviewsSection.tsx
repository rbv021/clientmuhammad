import React from 'react';
import { Star, CheckCircle, Quote, ExternalLink } from 'lucide-react';
import { REVIEWS, BUSINESS_INFO } from '../data/furnitureData';

export const ReviewsSection: React.FC = () => {
  return (
    <section id="reviews" className="py-24 bg-[#14100E] relative overflow-hidden border-t border-[#261E17]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header with Overall Google Rating Score */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] text-xs font-semibold uppercase tracking-wider mb-3">
              <span>Verified Customer Feedback</span>
            </div>
            <h2 className="font-display text-2xl sm:text-4xl font-bold text-[#F7F4EE]">
              Verbatim Review Highlights
            </h2>
            <p className="mt-2 text-sm sm:text-base text-[#A89D91] max-w-xl">
              Authentic experiences from residents and business owners across Dubai who bought or sold furniture with us.
            </p>
          </div>

          {/* Google Summary Badge */}
          <div className="wood-card p-4 rounded-xl border border-[#D4AF37]/30 flex items-center gap-4 shrink-0 shadow-lg">
            {/* Google colored G logo */}
            <div className="w-12 h-12 rounded-lg bg-white flex items-center justify-center shrink-0 shadow-sm">
              <svg className="w-7 h-7" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-display font-extrabold text-xl text-white">{BUSINESS_INFO.rating}</span>
                <div className="flex text-[#D4AF37]">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#D4AF37]" />
                  ))}
                </div>
              </div>
              <div className="text-xs text-[#9E9387] mt-0.5">
                Google Verified • {BUSINESS_INFO.reviewsCount}+ Local Reviews
              </div>
            </div>
          </div>
        </div>

        {/* 3 Verbatim Reviews Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {REVIEWS.map((review) => (
            <div
              key={review.id}
              className="wood-card p-6 rounded-2xl border border-[#2F261E] relative flex flex-col justify-between group hover:border-[#D4AF37]/50 transition-all duration-300"
            >
              {/* Quote Mark */}
              <Quote className="w-8 h-8 text-[#D4AF37]/20 absolute top-5 right-5" />

              <div>
                {/* Stars */}
                <div className="flex text-[#D4AF37] mb-4">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#D4AF37]" />
                  ))}
                </div>

                {/* Verbatim Review text */}
                <p className="text-sm text-[#DDD4CA] leading-relaxed italic">
                  "{review.text}"
                </p>
              </div>

              {/* Author & Verification badge */}
              <div className="mt-6 pt-4 border-t border-[#261E17] flex items-center justify-between">
                <div>
                  <div className="font-display font-bold text-sm text-white">
                    {review.author}
                  </div>
                  <div className="text-[11px] text-[#8C8074]">
                    {review.role}
                  </div>
                </div>

                <div className="flex items-center gap-1 text-[11px] font-medium text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/40">
                  <CheckCircle className="w-3 h-3 text-emerald-400" />
                  <span>{review.badge}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* External Google Review link */}
        <div className="mt-10 text-center">
          <a
            href={BUSINESS_INFO.googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-xs text-[#A89D91] hover:text-[#D4AF37] transition-colors"
          >
            <span>View Google Reviews & Map Location</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </section>
  );
};
