import React, { useState } from 'react';
import { Phone, MessageCircle, MapPin, Send, CheckCircle2, HelpCircle, ChevronDown } from 'lucide-react';
import { BUSINESS_INFO } from '../data/furnitureData';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    inquiryType: 'Selling Furniture (Request Valuation)',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);

    // Also offer direct WhatsApp redirect
    const msg = `Hello Muhammad Rafiq Used Furniture,\nName: ${formData.name}\nPhone: ${formData.phone}\nInquiry: ${formData.inquiryType}\nDetails: ${formData.message}`;
    const targetUrl = `https://wa.me/971559499593?text=${encodeURIComponent(msg)}`;
    window.open(targetUrl, '_blank');
  };

  const faqs = [
    {
      q: 'Do you provide furniture pickup and transportation?',
      a: 'Yes, we have our own transport trucks and moving crew. Once an item or lot is agreed upon, our team handles dismantling, carrying, and loading from your apartment or villa in Dubai or Sharjah without you lifting a finger.',
    },
    {
      q: 'What types of furniture do you purchase and sell?',
      a: 'We specialize in living room sofa sets (leather and fabric), complete bedroom suites, wardrobes, solid wood dining tables, corporate office desks, boardroom tables, and working major home appliances.',
    },
    {
      q: 'How quickly can you evaluate my furniture?',
      a: 'If you send clear photos via WhatsApp to +971 55 949 9593, our team usually replies with an evaluation within 15 to 30 minutes during showroom hours.',
    },
    {
      q: 'How does payment work when I sell furniture to you?',
      a: 'Payment is made immediately upon physical inspection and handover at your location before loading onto our truck.',
    },
    {
      q: 'Where is your physical showroom located?',
      a: 'We are located on Al Musalla Road, directly behind Al Sahar Hotel in Naif, Deira, Dubai. We are only 340 meters from Baniyas Square Metro Station.',
    },
  ];

  return (
    <section id="contact" className="py-24 bg-[#14100E] relative border-t border-[#261E17]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] text-xs font-semibold uppercase tracking-wider mb-3">
            <span>Get In Touch</span>
          </div>
          <h2 className="font-display text-2xl sm:text-4xl font-bold text-[#F7F4EE]">
            Contact Our Deira Team
          </h2>
          <p className="mt-2 text-sm sm:text-base text-[#A69B8E]">
            Have a question or want to discuss a bulk furniture clearance? Reach out directly by phone, WhatsApp, or the form below.
          </p>
        </div>

        {/* 3 Contact Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {/* Card 1: Tap to Call */}
          <div className="wood-card p-6 rounded-2xl border border-[#30261D] flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#221B15] border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] mb-4">
                <Phone className="w-6 h-6" />
              </div>
              <h3 className="font-display text-lg font-bold text-white">Call Direct</h3>
              <p className="text-xs text-[#9E9387] mt-1">Speak directly with our showroom manager</p>
              <div className="mt-4 font-mono font-bold text-base sm:text-lg text-[#D4AF37]">
                {BUSINESS_INFO.phone}
              </div>
            </div>
            <a
              href={`tel:${BUSINESS_INFO.phoneRaw}`}
              className="mt-6 w-full py-2.5 px-4 rounded-xl bg-[#D4AF37] hover:bg-[#E2C465] text-black font-bold text-xs text-center transition-all"
            >
              Tap to Call Now
            </a>
          </div>

          {/* Card 2: WhatsApp Photos */}
          <div className="wood-card p-6 rounded-2xl border border-[#30261D] flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#221B15] border border-[#25D366]/40 flex items-center justify-center text-[#25D366] mb-4">
                <MessageCircle className="w-6 h-6" />
              </div>
              <h3 className="font-display text-lg font-bold text-white">WhatsApp Valuation</h3>
              <p className="text-xs text-[#9E9387] mt-1">Send photos for rapid valuation response</p>
              <div className="mt-4 text-sm font-medium text-emerald-400">
                +971 55 949 9593
              </div>
            </div>
            <a
              href={`https://wa.me/971559499593?text=${encodeURIComponent('Hello Muhammad Rafiq Used Furniture, I would like to inquire about furniture:')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 w-full py-2.5 px-4 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-black font-bold text-xs text-center transition-all"
            >
              Open WhatsApp Chat
            </a>
          </div>

          {/* Card 3: Google Maps Navigation */}
          <div className="wood-card p-6 rounded-2xl border border-[#30261D] flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#221B15] border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] mb-4">
                <MapPin className="w-6 h-6" />
              </div>
              <h3 className="font-display text-lg font-bold text-white">Deira Showroom</h3>
              <p className="text-xs text-[#9E9387] mt-1">Behind Al Sahar Hotel, Al Musalla Rd</p>
              <div className="mt-4 text-xs text-[#CCC]">
                340m from Baniyas Square Metro
              </div>
            </div>
            <a
              href={BUSINESS_INFO.googleMapsDirectionsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 w-full py-2.5 px-4 rounded-xl bg-[#251E18] hover:bg-[#342A22] text-[#D4AF37] border border-[#D4AF37]/30 font-bold text-xs text-center transition-all"
            >
              Get Google Maps Directions
            </a>
          </div>
        </div>

        {/* 2 Columns: Contact Form & FAQ */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Quick Message Form */}
          <div className="lg:col-span-6 wood-card p-6 sm:p-8 rounded-2xl border border-[#D4AF37]/25 shadow-2xl">
            <h3 className="font-display text-xl font-bold text-white mb-2">Send an Online Inquiry</h3>
            <p className="text-xs text-[#A89D91] mb-6">Fill in the form to contact our desk or auto-transfer your message to WhatsApp.</p>

            {submitted ? (
              <div className="p-6 rounded-xl bg-emerald-950/40 border border-emerald-800 text-center space-y-3">
                <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                <h4 className="font-display font-bold text-white text-base">Inquiry Prepared!</h4>
                <p className="text-xs text-emerald-200">
                  Thank you! If WhatsApp did not open automatically, tap below to send directly to +971 55 949 9593.
                </p>
                <a
                  href={`https://wa.me/971559499593`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#25D366] text-black font-semibold text-xs"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Open WhatsApp</span>
                </a>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-[#D4AF37] mb-1.5 uppercase">
                    Your Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Tariq Ahmed"
                    className="w-full bg-[#1B1511] border border-[#2F251C] rounded-lg px-3.5 py-2.5 text-xs sm:text-sm text-white focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#D4AF37] mb-1.5 uppercase">
                    Phone / WhatsApp Number
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="e.g. +971 50 123 4567"
                    className="w-full bg-[#1B1511] border border-[#2F251C] rounded-lg px-3.5 py-2.5 text-xs sm:text-sm text-white focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#D4AF37] mb-1.5 uppercase">
                    Inquiry Type
                  </label>
                  <select
                    value={formData.inquiryType}
                    onChange={(e) => setFormData({ ...formData, inquiryType: e.target.value })}
                    className="w-full bg-[#1B1511] border border-[#2F251C] rounded-lg px-3.5 py-2.5 text-xs sm:text-sm text-white focus:border-[#D4AF37] focus:outline-none"
                  >
                    <option value="Selling Furniture (Request Valuation)">Selling Furniture (Request Valuation)</option>
                    <option value="Looking to Buy Furniture">Looking to Buy Furniture</option>
                    <option value="Full Flat/Villa Relocation Clearance">Full Flat/Villa Relocation Clearance</option>
                    <option value="Office & Commercial Liquidation">Office & Commercial Liquidation</option>
                    <option value="Showroom Visit Inquiry">Showroom Visit Inquiry</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#D4AF37] mb-1.5 uppercase">
                    Message / Item Details
                  </label>
                  <textarea
                    rows={3}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Describe your furniture, piece count, location in UAE..."
                    className="w-full bg-[#1B1511] border border-[#2F251C] rounded-lg px-3.5 py-2.5 text-xs sm:text-sm text-white focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B89020] text-black font-bold text-xs sm:text-sm tracking-wide shadow-lg hover:brightness-110 transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  <Send className="w-4 h-4 fill-black" />
                  <span>Send Message & Connect on WhatsApp</span>
                </button>
              </form>
            )}
          </div>

          {/* Frequently Asked Questions */}
          <div className="lg:col-span-6 space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <HelpCircle className="w-5 h-5 text-[#D4AF37]" />
              <h3 className="font-display text-xl font-bold text-white">Frequently Asked Questions</h3>
            </div>
            <p className="text-xs text-[#A89D91] mb-4">Common queries about buying, selling, and pickup procedures.</p>

            <div className="space-y-3">
              {faqs.map((faq, index) => (
                <div
                  key={index}
                  className="wood-card rounded-xl border border-[#2D231A] overflow-hidden transition-all"
                >
                  <button
                    type="button"
                    onClick={() => setOpenFaq(openFaq === index ? null : index)}
                    className="w-full p-4 text-left flex items-center justify-between gap-3 text-xs sm:text-sm font-semibold text-[#E8E4DF] hover:text-[#D4AF37]"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown
                      className={`w-4 h-4 text-[#D4AF37] shrink-0 transition-transform duration-200 ${
                        openFaq === index ? 'rotate-180' : ''
                      }`}
                    />
                  </button>

                  {openFaq === index && (
                    <div className="px-4 pb-4 pt-1 text-xs text-[#A89D91] leading-relaxed border-t border-[#261E17] animate-fadeIn">
                      {faq.a}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
