import React from 'react';
import { Sofa, Bed, Utensils, Briefcase, Home, Shield, ArrowRight, MessageCircle } from 'lucide-react';
import { BUSINESS_INFO } from '../data/furnitureData';

export const ServicesSection: React.FC = () => {
  const serviceCategories = [
    {
      icon: Sofa,
      title: 'Living Room Furniture',
      subtitle: 'We Buy & Sell',
      description: 'Leather sofa sets, fabric L-shape sectionals, recliner chairs, center coffee tables, and TV entertainment consoles in clean condition.',
      tags: ['Chesterfields', 'Corner Sofas', 'Accent Chairs', 'Coffee Tables'],
    },
    {
      icon: Bed,
      title: 'Bedroom Sets & Wardrobes',
      subtitle: 'We Buy & Sell',
      description: 'Solid wood king & queen bed frames, multi-door sliding wardrobes, vanity dressing tables with mirrors, and matching bedside nightstands.',
      tags: ['King Bed Sets', 'Cupboards & Closets', 'Dressers', 'Mattresses'],
    },
    {
      icon: Utensils,
      title: 'Dining Tables & Chairs',
      subtitle: 'We Buy & Sell',
      description: 'Solid teak, oak, and glass dining tables with 4, 6, and 8 matching chairs, plus dining credenzas and serving sideboards.',
      tags: ['6-Seater Tables', '8-Seater Suites', 'Padded Chairs', 'Buffet Counters'],
    },
    {
      icon: Briefcase,
      title: 'Office & Corporate Furniture',
      subtitle: 'Commercial Liquidation',
      description: 'Executive managerial desks, boardroom conference tables, ergonomic high-back mesh rolling chairs, and metal/wood filing cabinets.',
      tags: ['Executive Desks', 'Ergonomic Chairs', 'Meeting Tables', 'Filing Cabinets'],
    },
    {
      icon: Home,
      title: 'Full House & Apartment Clearance',
      subtitle: 'Relocation Specialist',
      description: 'Complete liquidation for departing expats, landlords, and estate movers. We purchase entire flat or villa furnishings in one visit.',
      tags: ['Same-Day Clearance', 'Cash on Pickup', 'All Rooms Handled', 'Own Moving Truck'],
    },
    {
      icon: Shield,
      title: 'Home Appliances & Electronics',
      subtitle: 'Tested & Functional',
      description: 'Working major home appliances including double-door refrigerators, automatic washing machines, cooking ranges, and flat-screen TVs.',
      tags: ['Refrigerators', 'Washing Machines', 'Cookers', 'Air Conditioners'],
    },
  ];

  return (
    <section id="services" className="py-20 bg-[#12100E] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] text-xs font-semibold uppercase tracking-wider mb-3">
            <span>Our Core Categories & Services</span>
          </div>
          <h2 className="font-display text-2xl sm:text-4xl font-bold text-[#F7F4EE]">
            What We Buy & Sell in Dubai
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#A89D91]">
            From individual premium pieces to entire home or corporate liquidations. Every piece is inspected for quality and priced transparently.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {serviceCategories.map((service) => {
            const Icon = service.icon;
            return (
              <div
                key={service.title}
                className="wood-card wood-card-hover p-6 rounded-2xl border border-[#2F261E] flex flex-col justify-between group"
              >
                <div>
                  {/* Top Icon & Subtitle */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-[#221B15] border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] group-hover:scale-110 group-hover:border-[#D4AF37] transition-all">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-semibold tracking-wider text-[#D4AF37] uppercase bg-[#D4AF37]/10 px-2.5 py-1 rounded-full border border-[#D4AF37]/20">
                      {service.subtitle}
                    </span>
                  </div>

                  <h3 className="font-display text-lg font-bold text-white group-hover:text-[#D4AF37] transition-colors">
                    {service.title}
                  </h3>

                  <p className="mt-2.5 text-xs sm:text-sm text-[#A69B8E] leading-relaxed">
                    {service.description}
                  </p>

                  {/* Tags */}
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {service.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-[10px] font-medium px-2 py-0.5 rounded bg-[#1A1512] text-[#B5ABA0] border border-[#2B231B]"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Quick Action Button */}
                <div className="mt-6 pt-4 border-t border-[#261E17] flex items-center justify-between">
                  <a
                    href={`https://wa.me/971559499593?text=${encodeURIComponent(`Hello, I have an inquiry regarding ${service.title}. Please provide valuation or available stock:`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#D4AF37] hover:text-[#F3DF95] group-hover:translate-x-1 transition-all"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
                    <span>Inquire via WhatsApp</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </a>

                  <a
                    href={`tel:${BUSINESS_INFO.phoneRaw}`}
                    className="text-[11px] text-[#8C8072] hover:text-white transition-colors"
                  >
                    Call Direct
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
