import React, { useState } from 'react';
import { Camera, Send, MessageCircle, Phone, Sparkles, Check } from 'lucide-react';
import { BUSINESS_INFO } from '../data/furnitureData';

export const WhatsAppEstimator: React.FC = () => {
  const [dealType, setDealType] = useState<'sell' | 'buy'>('sell');
  const [selectedCategory, setSelectedCategory] = useState('Living Room & Sofa Sets');
  const [condition, setCondition] = useState('Good Pre-Owned Condition');
  const [area, setArea] = useState('Deira / Bur Dubai');
  const [notes, setNotes] = useState('');

  const categories = [
    'Living Room & Sofa Sets',
    'Bedroom Sets & Wardrobes',
    'Dining Tables & Chair Sets',
    'Corporate Office Desks & Chairs',
    'Appliances & Electronics',
    'Full Villa / Flat Clearance',
  ];

  const conditions = [
    'Like New / Pristine',
    'Good Pre-Owned Condition',
    'Solid Wood / Antique',
    'Minor Wear (Usable & Complete)',
  ];

  const areas = [
    'Deira / Bur Dubai (Near Showroom)',
    'Sharjah / Ajman',
    'Downtown / Business Bay / DIFC',
    'Dubai Marina / JLT / Palm',
    'Al Barsha / Al Quoz / JVC',
    'Mirdif / Al Warqa / Silicon Oasis',
    'Other Area in UAE',
  ];

  const buildWhatsAppMessage = () => {
    const header = dealType === 'sell' ? '👋 Hello Muhammad Rafiq Used Furniture,' : '👋 Hello Muhammad Rafiq Used Furniture,';
    const intent = dealType === 'sell' 
      ? `I would like to get a valuation to SELL my furniture in UAE:` 
      : `I would like to INQUIRE about BUYING available furniture:`;

    const details = [
      header,
      '',
      intent,
      `• Category: ${selectedCategory}`,
      `• Condition: ${condition}`,
      `• Location: ${area}`,
      notes ? `• Details: ${notes}` : '',
      dealType === 'sell' ? `\nI will send photos right after this message. Please let me know your valuation & pickup timing!` : `\nPlease send me current showroom photos and pricing!`,
    ]
      .filter(Boolean)
      .join('\n');

    return encodeURIComponent(details);
  };

  const whatsappUrl = `https://wa.me/971559499593?text=${buildWhatsAppMessage()}`;

  return (
    <section id="quote" className="py-20 bg-[#161210] relative border-y border-[#261E17]">
      {/* Decorative Warm Ambient Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#D4AF37]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] text-xs font-semibold tracking-wider uppercase mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Instant WhatsApp Valuation</span>
          </div>
          <h2 className="font-display text-2xl sm:text-4xl font-bold text-[#F7F4EE]">
            Selling or Buying Furniture in Dubai?
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#BDB2A5]">
            Select your items below to auto-generate a direct inquiry to our Deira showroom team on WhatsApp. Fast response, fair appraisal, and same-day pickup.
          </p>
        </div>

        {/* Interactive Estimator Card */}
        <div className="wood-card rounded-2xl p-6 sm:p-8 border border-[#D4AF37]/25 shadow-2xl">
          {/* Toggle Sell vs Buy */}
          <div className="flex p-1 rounded-xl bg-[#0F0D0B] border border-[#2B231B] mb-6">
            <button
              type="button"
              onClick={() => setDealType('sell')}
              className={`flex-1 py-2.5 rounded-lg text-xs sm:text-sm font-bold transition-all ${
                dealType === 'sell'
                  ? 'bg-gradient-to-r from-[#D4AF37] to-[#B89020] text-black shadow-md'
                  : 'text-[#9C9287] hover:text-[#E8E4DF]'
              }`}
            >
              I Want to Sell Furniture (Cash Valuation)
            </button>
            <button
              type="button"
              onClick={() => setDealType('buy')}
              className={`flex-1 py-2.5 rounded-lg text-xs sm:text-sm font-bold transition-all ${
                dealType === 'buy'
                  ? 'bg-gradient-to-r from-[#D4AF37] to-[#B89020] text-black shadow-md'
                  : 'text-[#9C9287] hover:text-[#E8E4DF]'
              }`}
            >
              I Want to Buy Furniture (Showroom Stock)
            </button>
          </div>

          <div className="space-y-5">
            {/* 1. Category */}
            <div>
              <label className="block text-xs font-semibold text-[#D4AF37] uppercase tracking-wider mb-2">
                1. Select Furniture Category
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedCategory(cat)}
                    className={`p-3 rounded-lg text-xs text-left font-medium border transition-all ${
                      selectedCategory === cat
                        ? 'bg-[#D4AF37]/15 border-[#D4AF37] text-white shadow-sm'
                        : 'bg-[#1E1914] border-[#31281F] text-[#B8ACA0] hover:border-[#4D3F31]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="line-clamp-1">{cat}</span>
                      {selectedCategory === cat && <Check className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Condition & Area in 2 Columns */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-[#D4AF37] uppercase tracking-wider mb-2">
                  2. Approximate Condition
                </label>
                <select
                  value={condition}
                  onChange={(e) => setCondition(e.target.value)}
                  className="w-full bg-[#1E1914] border border-[#31281F] rounded-lg px-3.5 py-2.5 text-xs sm:text-sm text-[#EAE5DF] focus:border-[#D4AF37] focus:outline-none"
                >
                  {conditions.map((c) => (
                    <option key={c} value={c} className="bg-[#1E1914] text-white">
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#D4AF37] uppercase tracking-wider mb-2">
                  3. Your Location in UAE
                </label>
                <select
                  value={area}
                  onChange={(e) => setArea(e.target.value)}
                  className="w-full bg-[#1E1914] border border-[#31281F] rounded-lg px-3.5 py-2.5 text-xs sm:text-sm text-[#EAE5DF] focus:border-[#D4AF37] focus:outline-none"
                >
                  {areas.map((a) => (
                    <option key={a} value={a} className="bg-[#1E1914] text-white">
                      {a}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* 4. Notes */}
            <div>
              <label className="block text-xs font-semibold text-[#D4AF37] uppercase tracking-wider mb-2">
                4. Any specific details? (Brand, piece count, floor level)
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. 7-seater fabric sofa, 2nd floor with elevator in Naif..."
                className="w-full bg-[#1E1914] border border-[#31281F] rounded-lg px-3.5 py-2.5 text-xs sm:text-sm text-[#EAE5DF] focus:border-[#D4AF37] focus:outline-none placeholder-[#7A6F64]"
              />
            </div>

            {/* Photo Tip */}
            <div className="flex items-center gap-2.5 p-3 rounded-lg bg-[#110E0C] border border-[#2B231A] text-xs text-[#B5AAA0]">
              <Camera className="w-4 h-4 text-[#D4AF37] shrink-0" />
              <span>
                Tip: Taking 2–3 clear daylight photos speeds up WhatsApp valuation by 80%!
              </span>
            </div>

            {/* Actions */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:flex-1 flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-[#25D366] hover:bg-[#20bd5c] text-black font-bold text-sm tracking-wide shadow-lg shadow-[#25D366]/25 transition-all transform active:scale-95"
              >
                <MessageCircle className="w-5 h-5 fill-black" />
                <span>Open WhatsApp with Details (+971 55 949 9593)</span>
                <Send className="w-4 h-4" />
              </a>

              <a
                href={`tel:${BUSINESS_INFO.phoneRaw}`}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-[#29221B] hover:bg-[#382E25] border border-[#D4AF37]/40 text-[#E8E4DF] hover:text-[#D4AF37] font-semibold text-sm transition-colors"
              >
                <Phone className="w-4 h-4 text-[#D4AF37]" />
                <span>Call Directly</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
