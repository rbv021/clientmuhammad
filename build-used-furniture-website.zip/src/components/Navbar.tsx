import React, { useState, useEffect } from 'react';
import { Phone, MapPin, Clock, Menu, X, ArrowUpRight, MessageCircle } from 'lucide-react';
import { BUSINESS_INFO } from '../data/furnitureData';
import { getUAEBusinessStatus, BusinessStatusResult } from '../utils/businessStatus';

export const Navbar: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [status, setStatus] = useState<BusinessStatusResult>(getUAEBusinessStatus());
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    // Update live status every minute
    const interval = setInterval(() => {
      setStatus(getUAEBusinessStatus());
    }, 60000);

    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      clearInterval(interval);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const navLinks = [
    { label: 'About', href: '#about' },
    { label: 'Services', href: '#services' },
    { label: 'Inventory', href: '#inventory' },
    { label: 'Instant Quote', href: '#quote' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Hours & Location', href: '#location' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <>
      {/* Top Banner Bar */}
      <div className="bg-[#0D0B0A] border-b border-[#2A231C] text-xs text-[#B5ABA1] py-2 px-4 select-none relative z-50">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Location & Status */}
          <div className="flex items-center flex-wrap gap-x-4 gap-y-1">
            <a
              href={BUSINESS_INFO.googleMapsDirectionsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 hover:text-[#D4AF37] transition-colors"
            >
              <MapPin className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
              <span>Behind Al Sahar Hotel, Al Musalla Rd, Deira, Dubai</span>
            </a>

            <span className="hidden sm:inline-block text-[#4A4036]">•</span>

            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
              <span className="inline-flex items-center gap-1.5 font-medium">
                <span className={`w-2 h-2 rounded-full ${status.isOpen ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
                <span className={status.isOpen ? 'text-emerald-400 font-semibold' : 'text-amber-400'}>
                  {status.statusText}
                </span>
                <span className="text-[#8E847A] hidden md:inline">({status.subText})</span>
              </span>
            </div>
          </div>

          {/* Quick Call & WhatsApp on Bar */}
          <div className="flex items-center gap-4 ml-auto">
            <span className="text-[#8E847A] hidden lg:inline">Dubai Time: {status.uaeTimeFormatted}</span>
            <a
              href={`tel:${BUSINESS_INFO.phoneRaw}`}
              className="flex items-center gap-1.5 text-[#D4AF37] hover:text-[#F3DF95] font-medium transition-colors"
            >
              <Phone className="w-3.5 h-3.5" />
              <span className="font-sans font-semibold tracking-wide">{BUSINESS_INFO.phone}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Sticky Navigation */}
      <header
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#151210]/95 backdrop-blur-md shadow-2xl border-b border-[#2E261E] py-3'
            : 'bg-[#151210]/80 backdrop-blur-sm border-b border-[#251E18] py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Brand Logo */}
          <a href="#" className="flex items-center gap-3 group focus:outline-none">
            <div className="w-11 h-11 rounded-lg bg-[#221B15] border border-[#D4AF37]/40 flex items-center justify-center p-1.5 group-hover:border-[#D4AF37] transition-all duration-300 shadow-md">
              <svg viewBox="0 0 40 40" className="w-full h-full text-[#D4AF37]" fill="none" stroke="currentColor">
                <path d="M8 26h24v-2c0-2.2-1.8-4-4-4H12c-2.2 0-4 1.8-4 4v2z" fill="#D4AF37" fillOpacity="0.25" strokeWidth="2" />
                <path d="M12 20V12c0-2.2 1.8-4 4-4h8c2.2 0 4 1.8 4 4v8" strokeWidth="2" strokeLinecap="round" />
                <path d="M6 21c0-1.5 1-2.5 2.5-2.5h1.5v5H8.5C7 23.5 6 22.5 6 21z" strokeWidth="1.5" />
                <path d="M34 21c0-1.5-1-2.5-2.5-2.5H30v5h1.5c1.5 0 2.5-1 2.5-2.5z" strokeWidth="1.5" />
                <path d="M11 26v4M29 26v4" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </div>
            <div>
              <div className="font-display font-bold text-base sm:text-lg tracking-wider text-[#F7F4EE] group-hover:text-[#D4AF37] transition-colors leading-tight">
                MUHAMMAD RAFIQ
              </div>
              <div className="text-[10px] sm:text-xs tracking-[0.2em] font-semibold text-[#D4AF37] flex items-center gap-1">
                <span>USED FURNITURE</span>
                <span className="text-[#7D7368] font-normal">• DEIRA DUBAI</span>
              </div>
            </div>
          </a>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-6">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-sm font-medium text-[#D1C7BD] hover:text-[#D4AF37] transition-colors py-1 relative after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-[#D4AF37] hover:after:w-full after:transition-all"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Header Action Buttons */}
          <div className="hidden sm:flex items-center gap-3">
            <a
              href={`https://wa.me/971559499593?text=${encodeURIComponent('Hello Muhammad Rafiq Used Furniture, I would like to buy/sell furniture. Here are the details:')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-[#25D366]/15 hover:bg-[#25D366]/25 border border-[#25D366]/40 text-[#4EED88] text-xs sm:text-sm font-semibold transition-all duration-200"
            >
              <MessageCircle className="w-4 h-4 text-[#25D366]" />
              <span className="hidden md:inline">WhatsApp</span> Photos
            </a>

            <a
              href={`tel:${BUSINESS_INFO.phoneRaw}`}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-[#D4AF37] to-[#B89020] text-black font-semibold text-xs sm:text-sm hover:brightness-110 shadow-lg shadow-[#D4AF37]/15 transition-all duration-200 active:scale-95"
            >
              <Phone className="w-4 h-4 fill-black" />
              <span>Call Direct</span>
            </a>
          </div>

          {/* Mobile Menu Toggle Button */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg bg-[#241E18] text-[#E8E4DF] hover:text-[#D4AF37] border border-[#3A3026] focus:outline-none"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#171310] border-b border-[#2E261E] px-4 pt-3 pb-6 mt-3 space-y-3 shadow-2xl animate-fadeIn">
            <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#201A15] border border-[#332A20] text-xs">
              <span className="text-[#A89F95]">Store Status:</span>
              <span className={`font-semibold flex items-center gap-1.5 ${status.isOpen ? 'text-emerald-400' : 'text-amber-400'}`}>
                <span className={`w-2 h-2 rounded-full ${status.isOpen ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                {status.statusText} ({status.subText})
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <a
                href={`tel:${BUSINESS_INFO.phoneRaw}`}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg bg-[#D4AF37] text-black font-semibold text-sm"
              >
                <Phone className="w-4 h-4 fill-black" />
                <span>Call Shop</span>
              </a>
              <a
                href={`https://wa.me/971559499593?text=${encodeURIComponent('Hello Muhammad Rafiq Used Furniture, I would like to inquire about furniture.')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg bg-[#25D366] text-black font-semibold text-sm"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp</span>
              </a>
            </div>

            <nav className="divide-y divide-[#2B231C] pt-2">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center justify-between py-3 text-[#E8E4DF] hover:text-[#D4AF37] font-medium text-sm"
                >
                  <span>{link.label}</span>
                  <ArrowUpRight className="w-4 h-4 text-[#7A6F64]" />
                </a>
              ))}
            </nav>

            <a
              href={BUSINESS_INFO.googleMapsDirectionsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-2.5 rounded-lg bg-[#221C16] text-[#D4AF37] border border-[#D4AF37]/30 text-xs font-medium"
            >
              <MapPin className="w-4 h-4" />
              <span>Get Google Maps Directions</span>
            </a>
          </div>
        )}
      </header>
    </>
  );
};
