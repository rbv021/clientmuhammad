export interface FurnitureItem {
  id: string;
  title: string;
  category: 'living' | 'bedroom' | 'dining' | 'office' | 'appliances';
  categoryLabel: string;
  condition: 'Inspected - Like New' | 'Solid Hardwood' | 'Pristine Pre-Owned' | 'Corporate Grade';
  image: string;
  description: string;
  features: string[];
  dimensions?: string;
  material: string;
}

export interface ReviewItem {
  id: string;
  author: string;
  role: string;
  rating: number;
  date: string;
  text: string;
  badge: string;
  verified: boolean;
}

export interface BusinessHours {
  day: string;
  hours: string;
  isOpen: boolean;
}
